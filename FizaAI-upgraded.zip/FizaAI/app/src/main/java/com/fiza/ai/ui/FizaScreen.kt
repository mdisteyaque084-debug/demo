package com.fiza.ai.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.Color
import com.fiza.ai.FizaStatus
import com.fiza.ai.FizaUi

@Composable
fun FizaTheme(content: @Composable () -> Unit) {
    val scheme = if (isSystemInDarkTheme())
        darkColorScheme(primary = Color(0xFFFF8FB8), background = Color(0xFF14101A), surface = Color(0xFF1E1826))
    else
        lightColorScheme(primary = Color(0xFFD81B60), background = Color(0xFFFFF7FA), surface = Color(0xFFFFFFFF))
    MaterialTheme(colorScheme = scheme, content = content)
}

private fun statusText(s: FizaStatus) = when (s) {
    FizaStatus.IDLE -> "तैयार"
    FizaStatus.LISTENING -> "सुन रही हूँ…"
    FizaStatus.THINKING -> "सोच रही हूँ…"
    FizaStatus.SPEAKING -> "बोल रही हूँ…"
}

@Composable
fun FizaScreen(
    ui: FizaUi,
    onMic: () -> Unit,
    onStop: () -> Unit,
    onAccessibilitySetup: () -> Unit,
    onOpenDraft: () -> Unit,
    onDismissDraft: () -> Unit,
) {
    Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize().systemBarsPadding().padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text("Fiza AI", fontSize = 26.sp, color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(24.dp))
            Avatar(ui.status)
            Spacer(Modifier.height(12.dp))
            Text(statusText(ui.status), fontSize = 16.sp)
            Spacer(Modifier.height(16.dp))
            if (ui.transcript.isNotBlank()) Text("“${ui.transcript}”", textAlign = TextAlign.Center, fontSize = 18.sp)
            Spacer(Modifier.height(8.dp))
            Text(ui.reply, textAlign = TextAlign.Center, fontSize = 16.sp)
            if (ui.action.isNotBlank()) {
                Spacer(Modifier.height(6.dp))
                Text("क्रिया: ${ui.action}", fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
            }
            if (ui.hindiVoiceMissing) {
                Spacer(Modifier.height(8.dp))
                Text(
                    "Hindi voice install nahi hai. Settings → Text-to-speech mein Hindi voice download karein.",
                    fontSize = 12.sp, textAlign = TextAlign.Center,
                )
            }
            Spacer(Modifier.weight(1f))
            if (ui.history.isNotEmpty()) {
                Text("हाल के कमांड", fontSize = 12.sp)
                ui.history.take(3).forEach { Text("• $it", fontSize = 13.sp) }
                Spacer(Modifier.height(16.dp))
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                OutlinedButton(onClick = onStop) { Text("रोकें") }
                Button(onClick = onMic, modifier = Modifier.size(88.dp), shape = CircleShape) {
                    Text("🎤", fontSize = 32.sp)
                }
            }
            Spacer(Modifier.height(12.dp))
            OutlinedButton(onClick = onAccessibilitySetup) { Text("Screen control permission setup") }
            Text("Permission sirf tab enable karein jab aap Fiza ke screen actions chahte hain.", fontSize = 11.sp, textAlign = TextAlign.Center)
        }
    }
    if (ui.draftMessage != null) {
        AlertDialog(
            onDismissRequest = onDismissDraft,
            title = { Text("Message bhejne se pehle review") },
            text = {
                Column {
                    Text("Recipient: ${ui.draftRecipient ?: "WhatsApp mein khud select karein"}")
                    Spacer(Modifier.height(8.dp))
                    Text(ui.draftMessage)
                    Spacer(Modifier.height(8.dp))
                    Text("Fiza message automatically send nahi karegi. Contact verify karein aur WhatsApp mein manually Send dabayein.", fontSize = 12.sp)
                }
            },
            confirmButton = { Button(onClick = onOpenDraft) { Text("WhatsApp mein draft kholen") } },
            dismissButton = { TextButton(onClick = onDismissDraft) { Text("Cancel") } },
        )
    }
}

@Composable
private fun Avatar(status: FizaStatus) {
    val t = rememberInfiniteTransition(label = "pulse")
    val pulse by t.animateFloat(
        1f, if (status == FizaStatus.IDLE) 1.03f else 1.18f,
        infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "scale",
    )
    Box(
        Modifier.size(150.dp).scale(pulse).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.25f), CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            Modifier.size(110.dp).background(MaterialTheme.colorScheme.primary, CircleShape),
            contentAlignment = Alignment.Center,
        ) { Text("F", fontSize = 48.sp, color = Color.White) }
    }
}
